# Real-Time Vendor  > 2024-10-23 7:17pm
https://universe.roboflow.com/warehouse-object-detection-tyhg3/real-time-vendor

Provided by a Roboflow user
License: CC BY 4.0

